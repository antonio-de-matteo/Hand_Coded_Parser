/*
* Grammar:
        S -> Program EOF
        Program -> Stmt Program'
        Program' -> ; Stmt Program'
        Program' -> ''
        Stmt -> IF Expr THEN Stmt ELSE Stmt
        Stmt -> ID ASSIGN Expr
        Stmt -> DO Stmt WHILE Expr
        Expr -> T Expr'
        Expr' -> RELOP T Expr'
        Expr' -> ''
        T -> ID
        T -> Number
*
* */
import java.util.*;

public class RecDesParser {
    static int ptr;
    static Lexer lexicalAnalyzer = new Lexer();
    static Token token;

    public static void main(String args[]) throws Exception {
        String filePath = args[0];
        if(lexicalAnalyzer.initialize(filePath)) {
            if ((token = lexicalAnalyzer.nextToken()) != null) {
                //System.out.println(token.getName());
                //ptr = 0;
                //inizio dalla produzione S che è la prima produzione
                boolean isValid = S();
                if ((isValid)) {
                    System.out.println("The input string is valid.");
                } else {
                    System.out.println("The input string is invalid.");
                }
            }
        }


    }

    //classe che si occupa della produzione di s()
    static boolean S() throws Exception{
        //chiamo il metodo program che corrisponde alla produzione program
        if(Program()){
            String s= token.getName();
            //se dopo aver controllato program() ricevo true, mi manca solo EOF ed avrò successo
           if(s.equals("EOF"))
           {
               return true;
           }
        }
        return false;
    }

    //rappresenta la produzione di program
    static boolean Program() throws Exception {
        //viene chiamato stmt
        if(Stmt())
        {
            //viene chiamato program1 se entrambi danno true allora program darà true
            if(Program1())
            {
                return true;
            }
        }
        return false;
    }

    //rappresenta la produzione program1
    static boolean Program1() throws Exception {
        //token= lexicalAnalyzer.nextToken();
        String s= token.getName();
        //controllo se il token corrisponde ad uno di questi terminali
        if(s.equals("SEMI") || s.equals("ID")|| s.equals("DO")|| s.equals("IF"))
        {
            if(Stmt())
            {
                if(Program1())
                {
                    return true;
                }
            }

        }
        if(s.equals("EOF"))
        {
            return true;
        }
        return false;
    }

    static boolean Stmt() throws Exception {
        //token= lexicalAnalyzer.nextToken();
        String s= token.getName();
        if(s.equals("IF"))
        {
            if(Expr())
            {
                        token= lexicalAnalyzer.nextToken();
                        if (Stmt()) {
                            token = lexicalAnalyzer.nextToken();
                            s = token.getName();
                            if (s.equals("ELSE")) {
                                if (Stmt()) {
                                    return true;
                                }
                            }
                        }
            }
        }
        if(s.equals("ID"))
        {
            token= lexicalAnalyzer.nextToken();
            s= token.getName();
            if(s.equals("ASSIGN"))
            {
                if(Expr())
                {
                    return true;
                }
            }
        }
        if(s.equals("DO"))
        {
            token= lexicalAnalyzer.nextToken();
            //String s= token.getName();
            if(Stmt())
            {
                if(Expr())
                {
                    return true;
                }
            }
        }
        return false;
    }

    static boolean Expr() throws Exception {
        if(T())
        {
            if(Expr1())
            {
                return true;
            }
        }
        return false;
    }

    static boolean Expr1() throws Exception {
        //visto che chiamo il nexttoken, controllo se ho un terminale che viene dopo
        token= lexicalAnalyzer.nextToken();
        String s= token.getName();
        //System.out.println(s+":"+token.getAttribute());
        if(token == null || s.equals("EOF") )
        {
            return true;
        }

        if(s.equals("relop"))
        {
           if(T())
           {
               if(Expr1()) {
                   return true;
               }
           }
        }
        if(s.equals("SEMI"))
        {
            System.out.println(s);
            token= lexicalAnalyzer.nextToken();
            String c=token.getName();
            if(c.equals("EOF") || c.equals("ELSE") || c.equals("WHILE"))
            {
                return false;
            }
            return true;
        }
        if(s.equals("THEN"))
        {
            return true;
        }
        if(s.equals("ELSE"))
        {
            return true;
        }
        if(s.equals("WHILE"))
        {
            return true;
        }
        return false;
    }

    static boolean T() throws Exception {
        token= lexicalAnalyzer.nextToken();
        String s= token.getName();
        if(s.equals("ID") || s.equals("NUMBER"))
        {
            return true;
        }
        return false;
    }


}
